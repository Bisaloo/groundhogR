Sys.setenv("R_ENVIRON" = tempfile("renviron"))
Sys.setenv("GROUNDHOG_FOLDER" = tempfile("groundhog"))
